This is a placeholder so the images folder is included in the zip. You can delete this file and add your assets.
