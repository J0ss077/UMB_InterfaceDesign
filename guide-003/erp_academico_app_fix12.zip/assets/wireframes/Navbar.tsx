import React from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { User, Shield, LogOut } from 'lucide-react';

interface NavbarProps {
  currentScreen: string;
  onNavigate: (screen: string) => void;
  userRole: 'usuario' | 'admin';
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentScreen, onNavigate, userRole, onLogout }) => {
  const allMenuItems = [
    { id: 'dashboard', label: 'Dashboard', roles: ['usuario', 'admin'] },
    { id: 'solicitudes', label: 'Solicitudes', roles: ['usuario', 'admin'] },
    { id: 'aprobaciones', label: 'Aprobaciones', roles: ['admin'] },
    { id: 'preparacion', label: 'Preparación', roles: ['admin'] },
    { id: 'confirmacion', label: 'Confirmación', roles: ['admin'] },
  ];

  const menuItems = allMenuItems.filter(item => item.roles.includes(userRole));

  return (
    <nav className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center">
          <h1 className="text-primary mr-12">ERP Académico</h1>
        </div>
        
        <div className="flex items-center space-x-8">
          {menuItems.map((item) => (
            <motion.button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`relative px-4 py-2 rounded-lg transition-colors ${
                currentScreen === item.id
                  ? 'text-primary bg-blue-50'
                  : 'text-gray-600 hover:text-primary hover:bg-gray-50'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {item.label}
              {currentScreen === item.id && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"
                  initial={false}
                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
              )}
            </motion.button>
          ))}
        </div>
        
        {/* User Info and Logout */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 px-3 py-1 bg-gray-100 rounded-lg">
            {userRole === 'admin' ? (
              <Shield className="w-4 h-4 text-green-600" />
            ) : (
              <User className="w-4 h-4 text-blue-600" />
            )}
            <span className="text-sm capitalize">{userRole}</span>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={onLogout}
            className="flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            Cerrar sesión
          </Button>
        </div>
      </div>
    </nav>
  );
};