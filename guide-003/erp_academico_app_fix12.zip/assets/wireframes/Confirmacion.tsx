import React from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { CheckCircle, ArrowLeft, Calendar, MapPin, Clock, User } from 'lucide-react';

interface ConfirmacionProps {
  onNavigate: (screen: string) => void;
}

export const Confirmacion: React.FC<ConfirmacionProps> = ({ onNavigate }) => {
  const solicitudDetails = {
    id: 'SOL-001',
    docente: 'Dr. María González',
    espacio: 'Aula 201',
    fecha: '15 de Septiembre, 2024',
    horario: '08:00 - 10:00',
    recursos: ['Microscopios x3', 'Proyector 4K', 'Sistema de Sonido'],
    estudiantes: 35
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ 
          duration: 0.6,
          type: "spring",
          stiffness: 100,
          damping: 15
        }}
        className="max-w-2xl w-full"
      >
        <Card className="text-center overflow-hidden">
          <CardContent className="p-12">
            {/* Success Icon */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ 
                delay: 0.2,
                type: "spring",
                stiffness: 200,
                damping: 10
              }}
              className="flex justify-center mb-6"
            >
              <div className="relative">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 w-24 h-24 border-4 border-green-200 border-t-green-500 rounded-full"
                />
                <CheckCircle className="w-24 h-24 text-green-500" />
              </div>
            </motion.div>

            {/* Success Message */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4, duration: 0.5 }}
            >
              <h1 className="text-green-600 mb-4">¡Solicitud completada!</h1>
              <p className="text-gray-600 mb-8">
                El espacio ha sido reservado y la entrega registrada.
              </p>
            </motion.div>

            {/* Details Summary */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.5 }}
              className="bg-gray-50 rounded-lg p-6 mb-8 text-left"
            >
              <h3 className="text-center mb-6">Resumen de la reserva</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <User className="w-5 h-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Docente</p>
                      <p>{solicitudDetails.docente}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Espacio</p>
                      <p>{solicitudDetails.espacio}</p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Calendar className="w-5 h-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Fecha</p>
                      <p>{solicitudDetails.fecha}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-gray-500" />
                    <div>
                      <p className="text-sm text-gray-500">Horario</p>
                      <p>{solicitudDetails.horario}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Resources */}
              {solicitudDetails.recursos.length > 0 && (
                <div className="mt-6">
                  <p className="text-sm text-gray-500 mb-3">Recursos entregados</p>
                  <div className="flex flex-wrap gap-2">
                    {solicitudDetails.recursos.map((recurso, index) => (
                      <motion.span
                        key={recurso}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.8 + index * 0.1 }}
                        className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm"
                      >
                        ✓ {recurso}
                      </motion.span>
                    ))}
                  </div>
                </div>
              )}

              {/* Reference Number */}
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-500">Número de referencia</p>
                <p className="text-lg font-mono text-blue-600">{solicitudDetails.id}</p>
              </div>
            </motion.div>

            {/* Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.5 }}
              className="space-y-4"
            >
              <Button
                onClick={() => onNavigate('dashboard')}
                size="lg"
                className="w-full"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Volver al dashboard
              </Button>
              
              <div className="flex gap-4">
                <Button
                  variant="outline"
                  onClick={() => window.print()}
                  className="flex-1"
                >
                  Imprimir comprobante
                </Button>
                <Button
                  variant="outline"
                  onClick={() => onNavigate('solicitudes')}
                  className="flex-1"
                >
                  Nueva solicitud
                </Button>
              </div>
            </motion.div>

            {/* Floating particles effect */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              {Array.from({ length: 6 }).map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-2 h-2 bg-green-400 rounded-full opacity-70"
                  animate={{
                    y: [-20, -100],
                    x: [0, Math.random() * 100 - 50],
                    opacity: [0.7, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    delay: i * 0.5,
                    ease: "easeOut"
                  }}
                  style={{
                    left: `${20 + i * 10}%`,
                    top: '100%',
                  }}
                />
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Additional Actions */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.5 }}
          className="mt-6 text-center"
        >
          <p className="text-sm text-gray-500 mb-2">
            ¿Necesitas ayuda? Contacta al soporte técnico
          </p>
          <Button variant="link" className="text-sm">
            soporte@universidad.edu
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
};