import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ScrollArea } from './ui/scroll-area';
import { Check, Clock, Package, Truck } from 'lucide-react';

interface PreparacionProps {
  onNavigate: (screen: string) => void;
}

const steps = [
  { id: 1, name: 'Orden creada', icon: Package, status: 'completed' },
  { id: 2, name: 'Preparando', icon: Clock, status: 'active' },
  { id: 3, name: 'Listo', icon: Check, status: 'pending' },
  { id: 4, name: 'Entregado', icon: Truck, status: 'pending' },
];

const recursos = [
  {
    id: 1,
    nombre: 'Microscopios x3',
    ubicacion: 'Aula 201',
    estado: 'Preparando',
    progreso: 75,
    estimado: '5 min restantes',
    responsable: 'Ana García'
  },
  {
    id: 2,
    nombre: 'Proyector 4K',
    ubicacion: 'Auditorio Cine',
    estado: 'Listo',
    progreso: 100,
    estimado: 'Completado',
    responsable: 'Carlos López'
  },
  {
    id: 3,
    nombre: 'Sistema de Sonido',
    ubicacion: 'Auditorio Cine',
    estado: 'Preparando',
    progreso: 30,
    estimado: '15 min restantes',
    responsable: 'María González'
  },
  {
    id: 4,
    nombre: 'Reactivos Químicos',
    ubicacion: 'Laboratorio Química',
    estado: 'Pendiente',
    progreso: 0,
    estimado: '20 min restantes',
    responsable: 'Luis Martínez'
  },
  {
    id: 5,
    nombre: 'Cabinas de Audio x5',
    ubicacion: 'Auditorio Idiomas',
    estado: 'Listo',
    progreso: 100,
    estimado: 'Completado',
    responsable: 'Patricia Silva'
  }
];

export const Preparacion: React.FC<PreparacionProps> = ({ onNavigate }) => {
  const [currentProgress, setCurrentProgress] = useState(65);
  const [recursos_state, setRecursosState] = useState(recursos);

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      setRecursosState(prev => prev.map(recurso => {
        if (recurso.estado === 'Preparando' && recurso.progreso < 100) {
          const newProgress = Math.min(recurso.progreso + Math.random() * 10, 100);
          return {
            ...recurso,
            progreso: newProgress,
            estado: newProgress === 100 ? 'Listo' : recurso.estado,
            estimado: newProgress === 100 ? 'Completado' : recurso.estimado
          };
        }
        return recurso;
      }));
      
      // Update overall progress
      setCurrentProgress(prev => {
        const completedItems = recursos_state.filter(r => r.estado === 'Listo').length;
        return (completedItems / recursos_state.length) * 100;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [recursos_state]);

  const getStatusColor = (estado: string) => {
    switch (estado) {
      case 'Listo':
        return 'bg-green-500';
      case 'Preparando':
        return 'bg-blue-500';
      case 'Pendiente':
        return 'bg-gray-400';
      default:
        return 'bg-gray-400';
    }
  };

  const allReady = recursos_state.every(r => r.estado === 'Listo');

  return (
    <div className="max-w-6xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="mb-8">Preparación y entrega</h1>

        {/* Stepper */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Progreso de la orden</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-6">
              {steps.map((step, index) => {
                const Icon = step.icon;
                const isActive = step.status === 'active';
                const isCompleted = step.status === 'completed';
                const isPending = step.status === 'pending';

                return (
                  <div key={step.id} className="flex items-center">
                    <motion.div
                      className={`flex items-center justify-center w-12 h-12 rounded-full ${
                        isCompleted ? 'bg-green-500 text-white' :
                        isActive ? 'bg-blue-500 text-white' :
                        'bg-gray-200 text-gray-500'
                      }`}
                      animate={isActive ? { scale: [1, 1.1, 1] } : { scale: 1 }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <Icon className="w-6 h-6" />
                    </motion.div>
                    <div className="ml-3">
                      <p className={`text-sm ${isActive ? 'text-blue-600' : isCompleted ? 'text-green-600' : 'text-gray-500'}`}>
                        {step.name}
                      </p>
                    </div>
                    {index < steps.length - 1 && (
                      <div className={`w-16 h-0.5 mx-4 ${isCompleted ? 'bg-green-500' : 'bg-gray-200'}`} />
                    )}
                  </div>
                );
              })}
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progreso general</span>
                <span>{Math.round(currentProgress)}%</span>
              </div>
              <Progress value={currentProgress} className="w-full" />
            </div>
          </CardContent>
        </Card>

        {/* Resources List */}
        <Card>
          <CardHeader>
            <CardTitle>Recursos en preparación</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px]">
              <div className="space-y-4">
                {recursos_state.map((recurso, index) => (
                  <motion.div
                    key={recurso.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="p-4 border rounded-lg hover:shadow-md transition-shadow"
                    whileHover={{ scale: 1.02 }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="font-medium">{recurso.nombre}</h3>
                        <p className="text-sm text-gray-600">
                          {recurso.ubicacion} • {recurso.responsable}
                        </p>
                      </div>
                      <Badge className={getStatusColor(recurso.estado)}>
                        {recurso.estado}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progreso</span>
                        <span>{recurso.estimado}</span>
                      </div>
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: '100%' }}
                      >
                        <Progress value={recurso.progreso} className="w-full" />
                      </motion.div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Confirm Delivery Button */}
        <motion.div
          className="mt-8 flex justify-center"
          animate={allReady ? { scale: [1, 1.05, 1] } : { scale: 1 }}
          transition={{ duration: 1, repeat: allReady ? Infinity : 0 }}
        >
          <Button
            size="lg"
            onClick={() => onNavigate('confirmacion')}
            disabled={!allReady}
            className={`px-8 py-3 ${allReady ? 'bg-green-600 hover:bg-green-700' : ''}`}
          >
            {allReady ? 'Confirmar entrega' : 'Esperando preparación...'}
          </Button>
        </motion.div>

        {/* Status Summary */}
        <motion.div
          className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl text-green-600 mb-1">
                {recursos_state.filter(r => r.estado === 'Listo').length}
              </div>
              <div className="text-sm text-gray-600">Listos</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl text-blue-600 mb-1">
                {recursos_state.filter(r => r.estado === 'Preparando').length}
              </div>
              <div className="text-sm text-gray-600">En preparación</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl text-gray-600 mb-1">
                {recursos_state.filter(r => r.estado === 'Pendiente').length}
              </div>
              <div className="text-sm text-gray-600">Pendientes</div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  );
};