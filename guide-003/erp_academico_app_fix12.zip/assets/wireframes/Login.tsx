import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

import { AlertCircle, User, Shield } from 'lucide-react';

interface LoginProps {
  onLogin: (role: 'usuario' | 'admin') => void;
}

// Demo credentials
const demoCredentials = {
  admin: { email: 'admin@academia.umb.edu.co', password: 'admin' },
  usuario: { email: 'profesor@academia.umb.edu.co', password: 'profesor123' }
};

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Validate domain
    if (!formData.email.endsWith('@academia.umb.edu.co')) {
      setError('Debe usar un correo del dominio @academia.umb.edu.co');
      setIsLoading(false);
      return;
    }

    // Determine role based on email
    const isAdmin = formData.email === 'admin@academia.umb.edu.co';
    const role = isAdmin ? 'admin' : 'usuario';
    const credentials = demoCredentials[role];
    
    if (formData.email === credentials.email && formData.password === credentials.password) {
      onLogin(role);
    } else {
      setError('Credenciales incorrectas');
    }
    
    setIsLoading(false);
  };

  const fillDemoCredentials = (role: 'usuario' | 'admin') => {
    const credentials = demoCredentials[role];
    setFormData({
      email: credentials.email,
      password: credentials.password
    });
    setError('');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-teal-50 p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="mx-auto mb-4 w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center"
            >
              <User className="w-8 h-8 text-white" />
            </motion.div>
            <CardTitle className="text-primary">ERP Académico</CardTitle>
            <p className="text-gray-600">Gestión de espacios académicos</p>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Email */}
              <div className="space-y-2">
                <Label htmlFor="email">Correo electrónico</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="nombre@academia.umb.edu.co"
                  required
                />
              </div>

              {/* Password */}
              <div className="space-y-2">
                <Label htmlFor="password">Contraseña</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="••••••••"
                  required
                />
              </div>

              {/* Error Message */}
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 text-red-600 text-sm p-3 bg-red-50 rounded-lg"
                >
                  <AlertCircle className="w-4 h-4" />
                  {error}
                </motion.div>
              )}

              {/* Login Button */}
              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}
              >
                {isLoading ? 'Iniciando sesión...' : 'Iniciar sesión'}
              </Button>
            </form>

            {/* Demo Credentials */}
            <div className="mt-6 space-y-3">
              <p className="text-sm text-gray-500 text-center">Credenciales de demostración:</p>
              
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => fillDemoCredentials('usuario')}
                  className="flex-1 text-xs"
                >
                  <User className="w-3 h-3 mr-1" />
                  Profesor Demo
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => fillDemoCredentials('admin')}
                  className="flex-1 text-xs"
                >
                  <Shield className="w-3 h-3 mr-1" />
                  Admin Demo
                </Button>
              </div>
              
              <div className="text-xs text-gray-400 space-y-1">
                <p>• Profesor: profesor@academia.umb.edu.co / profesor123</p>
                <p>• Admin: admin@academia.umb.edu.co / admin</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Information Card */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-6"
        >
          <div className="bg-white p-4 rounded-lg shadow text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <User className="w-4 h-4 text-primary" />
              <span className="font-medium">Sistema ERP Académico UMB</span>
            </div>
            <p className="text-sm text-gray-600 mb-3">
              Use su correo institucional para acceder al sistema
            </p>
            <div className="text-xs text-gray-500 space-y-1">
              <p>• Los administradores son identificados automáticamente</p>
              <p>• Todos los usuarios deben usar el dominio @academia.umb.edu.co</p>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
};