import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Login } from './components/Login';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { Solicitudes } from './components/Solicitudes';
import { Aprobaciones } from './components/Aprobaciones';
import { Preparacion } from './components/Preparacion';
import { Confirmacion } from './components/Confirmacion';
import { AccessDenied } from './components/AccessDenied';

type Screen = 'dashboard' | 'solicitudes' | 'aprobaciones' | 'preparacion' | 'confirmacion';
type UserRole = 'usuario' | 'admin' | null;

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = (role: 'usuario' | 'admin') => {
    setUserRole(role);
    setIsAuthenticated(true);
    setCurrentScreen('dashboard');
  };

  const handleLogout = () => {
    setUserRole(null);
    setIsAuthenticated(false);
    setCurrentScreen('dashboard');
  };

  const handleNavigate = (screen: string) => {
    // Check if user has permission to access this screen
    if (userRole === 'usuario' && ['aprobaciones', 'preparacion', 'confirmacion'].includes(screen)) {
      return; // Prevent navigation to admin-only screens
    }
    setCurrentScreen(screen as Screen);
  };

  // Show login if not authenticated
  if (!isAuthenticated || !userRole) {
    return <Login onLogin={handleLogin} />;
  }

  const renderScreen = () => {
    // Check if user has permission to view this screen
    if (userRole === 'usuario' && ['aprobaciones', 'preparacion', 'confirmacion'].includes(currentScreen)) {
      return <AccessDenied onNavigate={handleNavigate} />;
    }

    switch (currentScreen) {
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} userRole={userRole} />;
      case 'solicitudes':
        return <Solicitudes onNavigate={handleNavigate} />;
      case 'aprobaciones':
        return <Aprobaciones onNavigate={handleNavigate} />;
      case 'preparacion':
        return <Preparacion onNavigate={handleNavigate} />;
      case 'confirmacion':
        return <Confirmacion onNavigate={handleNavigate} />;
      default:
        return <Dashboard onNavigate={handleNavigate} userRole={userRole} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar 
        currentScreen={currentScreen} 
        onNavigate={handleNavigate} 
        userRole={userRole}
        onLogout={handleLogout}
      />
      
      <AnimatePresence mode="wait">
        <motion.div
          key={currentScreen}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ 
            duration: 0.3,
            ease: "easeInOut"
          }}
          className="min-h-[calc(100vh-80px)]"
        >
          {renderScreen()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}