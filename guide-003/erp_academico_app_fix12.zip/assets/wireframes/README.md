
  # Web ERP Application Wireframe

  This is a code bundle for Web ERP Application Wireframe. The original project is available at https://www.figma.com/design/JRuilO164DlixdXcWcYI5T/Web-ERP-Application-Wireframe.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  