import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { ScrollArea } from './ui/scroll-area';
import { ChevronDown, ChevronRight, Clock, User, MapPin } from 'lucide-react';

interface AprobacionesProps {
  onNavigate: (screen: string) => void;
}

const solicitudes = [
  {
    id: 'SOL-001',
    solicitante: 'Dr. María González',
    espacio: 'Aula 201',
    piso: 2,
    franja: '08:00 - 10:00',
    fecha: '2024-09-15',
    estado: 'Pendiente',
    recursos: ['Proyector', 'Sonido'],
    materia: 'Matemáticas Avanzadas',
    estudiantes: 35,
    observaciones: 'Clase magistral con presentación multimedia'
  },
  {
    id: 'SOL-002',
    solicitante: 'Prof. Carlos Ruiz',
    espacio: 'Laboratorio de Química',
    piso: 2,
    franja: '14:00 - 16:00',
    fecha: '2024-09-16',
    estado: 'Pendiente',
    recursos: ['Microscopios', 'Reactivos'],
    materia: 'Química Orgánica',
    estudiantes: 20,
    observaciones: 'Práctica de laboratorio - síntesis orgánica'
  },
  {
    id: 'SOL-003',
    solicitante: 'Dra. Ana López',
    espacio: 'Auditorio de Cine',
    piso: 0,
    franja: '10:00 - 12:00',
    fecha: '2024-09-17',
    estado: 'Aprobado',
    recursos: ['Proyector', 'Sonido'],
    materia: 'Historia del Arte',
    estudiantes: 80,
    observaciones: 'Conferencia magistral con material audiovisual'
  },
  {
    id: 'SOL-004',
    solicitante: 'Prof. Luis Martínez',
    espacio: 'Aula 305',
    piso: 3,
    franja: '16:00 - 18:00',
    fecha: '2024-09-18',
    estado: 'Rechazado',
    recursos: [],
    materia: 'Física Cuántica',
    estudiantes: 25,
    observaciones: 'Clase teórica'
  },
  {
    id: 'SOL-005',
    solicitante: 'Dr. Patricia Silva',
    espacio: 'Laboratorio de Biología',
    piso: 5,
    franja: '09:00 - 11:00',
    fecha: '2024-09-19',
    estado: 'Pendiente',
    recursos: ['Microscopios'],
    materia: 'Biología Celular',
    estudiantes: 18,
    observaciones: 'Observación de muestras celulares'
  }
];

export const Aprobaciones: React.FC<AprobacionesProps> = ({ onNavigate }) => {
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [selectedSolicitud, setSelectedSolicitud] = useState<string>('');
  const [rejectReason, setRejectReason] = useState('');
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const toggleRowExpansion = (id: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedRows(newExpanded);
  };

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleReject = (solicitudId: string) => {
    setSelectedSolicitud(solicitudId);
    setShowRejectModal(true);
  };

  const confirmReject = () => {
    // Handle rejection logic
    setShowRejectModal(false);
    setRejectReason('');
    onNavigate('solicitudes');
  };

  const handleApprove = (solicitudId: string) => {
    // Handle approval logic
    onNavigate('preparacion');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pendiente':
        return 'bg-yellow-500';
      case 'Aprobado':
        return 'bg-green-500';
      case 'Rechazado':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="mb-8">Aprobación de solicitudes</h1>

        <div className="bg-white rounded-lg border">
          <ScrollArea className="h-[700px]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12"></TableHead>
                  <TableHead 
                    className="cursor-pointer hover:bg-gray-50"
                    onClick={() => handleSort('id')}
                  >
                    ID
                  </TableHead>
                  <TableHead 
                    className="cursor-pointer hover:bg-gray-50"
                    onClick={() => handleSort('solicitante')}
                  >
                    Solicitante
                  </TableHead>
                  <TableHead 
                    className="cursor-pointer hover:bg-gray-50"
                    onClick={() => handleSort('espacio')}
                  >
                    Espacio
                  </TableHead>
                  <TableHead 
                    className="cursor-pointer hover:bg-gray-50"
                    onClick={() => handleSort('piso')}
                  >
                    Piso
                  </TableHead>
                  <TableHead 
                    className="cursor-pointer hover:bg-gray-50"
                    onClick={() => handleSort('franja')}
                  >
                    Franja
                  </TableHead>
                  <TableHead 
                    className="cursor-pointer hover:bg-gray-50"
                    onClick={() => handleSort('estado')}
                  >
                    Estado
                  </TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {solicitudes.map((solicitud) => (
                  <React.Fragment key={solicitud.id}>
                    <motion.tr
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="hover:bg-gray-50 transition-colors"
                    >
                      <TableCell>
                        <motion.button
                          onClick={() => toggleRowExpansion(solicitud.id)}
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="p-1 hover:bg-gray-200 rounded"
                        >
                          {expandedRows.has(solicitud.id) ? (
                            <ChevronDown className="w-4 h-4" />
                          ) : (
                            <ChevronRight className="w-4 h-4" />
                          )}
                        </motion.button>
                      </TableCell>
                      <TableCell className="font-medium">{solicitud.id}</TableCell>
                      <TableCell>{solicitud.solicitante}</TableCell>
                      <TableCell>{solicitud.espacio}</TableCell>
                      <TableCell>{solicitud.piso}</TableCell>
                      <TableCell>{solicitud.franja}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(solicitud.estado)}>
                          {solicitud.estado}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {solicitud.estado === 'Pendiente' && (
                          <div className="flex gap-2">
                            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                              <Button
                                variant="destructive"
                                size="sm"
                                onClick={() => handleReject(solicitud.id)}
                              >
                                Rechazar
                              </Button>
                            </motion.div>
                            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                              <Button
                                size="sm"
                                onClick={() => handleApprove(solicitud.id)}
                              >
                                Aprobar
                              </Button>
                            </motion.div>
                          </div>
                        )}
                      </TableCell>
                    </motion.tr>
                    
                    <AnimatePresence>
                      {expandedRows.has(solicitud.id) && (
                        <motion.tr
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.3 }}
                        >
                          <TableCell colSpan={8}>
                            <motion.div
                              initial={{ opacity: 0, y: -10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -10 }}
                              className="p-4 bg-gray-50 rounded-lg space-y-4"
                            >
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                <div className="flex items-center gap-2">
                                  <User className="w-4 h-4 text-gray-500" />
                                  <div>
                                    <p className="text-sm text-gray-500">Materia</p>
                                    <p>{solicitud.materia}</p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Clock className="w-4 h-4 text-gray-500" />
                                  <div>
                                    <p className="text-sm text-gray-500">Fecha</p>
                                    <p>{solicitud.fecha}</p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  <MapPin className="w-4 h-4 text-gray-500" />
                                  <div>
                                    <p className="text-sm text-gray-500">Estudiantes</p>
                                    <p>{solicitud.estudiantes}</p>
                                  </div>
                                </div>
                              </div>
                              
                              {solicitud.recursos.length > 0 && (
                                <div>
                                  <p className="text-sm text-gray-500 mb-2">Recursos solicitados</p>
                                  <div className="flex gap-2 flex-wrap">
                                    {solicitud.recursos.map((recurso) => (
                                      <Badge key={recurso} variant="outline">
                                        {recurso}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                              
                              <div>
                                <p className="text-sm text-gray-500 mb-2">Observaciones</p>
                                <p className="text-sm">{solicitud.observaciones}</p>
                              </div>
                            </motion.div>
                          </TableCell>
                        </motion.tr>
                      )}
                    </AnimatePresence>
                  </React.Fragment>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        </div>
      </motion.div>

      {/* Reject Modal */}
      <Dialog open={showRejectModal} onOpenChange={setShowRejectModal}>
        <DialogContent>
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2 }}
          >
            <DialogHeader>
              <DialogTitle>Motivo del rechazo</DialogTitle>
              <DialogDescription>
                Por favor, indique el motivo por el cual se rechaza la solicitud {selectedSolicitud}.
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4">
              <Label htmlFor="reject-reason">Motivo</Label>
              <Textarea
                id="reject-reason"
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Escriba aquí el motivo del rechazo..."
                className="mt-2"
                rows={4}
              />
            </div>
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowRejectModal(false)}
              >
                Cancelar
              </Button>
              <Button
                variant="destructive"
                onClick={confirmReject}
                disabled={!rejectReason.trim()}
              >
                Rechazar
              </Button>
            </DialogFooter>
          </motion.div>
        </DialogContent>
      </Dialog>
    </div>
  );
};