import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ScrollArea } from './ui/scroll-area';
import { Search, Calendar, Clock, Shield } from 'lucide-react';

interface DashboardProps {
  onNavigate: (screen: string) => void;
  userRole: 'usuario' | 'admin';
}

const spaces = [
  // Salones
  ...Array.from({ length: 6 }, (_, i) => ({ id: `aula-${-101 - i}`, name: `Aula -${101 + i}`, type: 'salon', floor: -1, status: Math.random() > 0.5 ? 'Disponible' : 'Ocupado' })),
  ...Array.from({ length: 14 }, (_, i) => ({ id: `aula-${101 + i}`, name: `Aula ${101 + i}`, type: 'salon', floor: 1, status: Math.random() > 0.5 ? 'Disponible' : 'Ocupado' })),
  ...Array.from({ length: 14 }, (_, i) => ({ id: `aula-${201 + i}`, name: `Aula ${201 + i}`, type: 'salon', floor: 2, status: Math.random() > 0.5 ? 'Disponible' : 'Ocupado' })),
  ...Array.from({ length: 14 }, (_, i) => ({ id: `aula-${301 + i}`, name: `Aula ${301 + i}`, type: 'salon', floor: 3, status: Math.random() > 0.5 ? 'Disponible' : 'Ocupado' })),
  ...Array.from({ length: 14 }, (_, i) => ({ id: `aula-${401 + i}`, name: `Aula ${401 + i}`, type: 'salon', floor: 4, status: Math.random() > 0.5 ? 'Disponible' : 'Ocupado' })),
  ...Array.from({ length: 14 }, (_, i) => ({ id: `aula-${501 + i}`, name: `Aula ${501 + i}`, type: 'salon', floor: 5, status: Math.random() > 0.5 ? 'Disponible' : 'Ocupado' })),
  ...Array.from({ length: 10 }, (_, i) => ({ id: `aula-${601 + i}`, name: `Aula ${601 + i}`, type: 'salon', floor: 6, status: Math.random() > 0.5 ? 'Disponible' : 'Ocupado' })),
  ...Array.from({ length: 5 }, (_, i) => ({ id: `aula-${701 + i}`, name: `Aula ${701 + i}`, type: 'salon', floor: 7, status: Math.random() > 0.5 ? 'Disponible' : 'Ocupado' })),
  
  // Laboratorios
  { id: 'lab-quimica', name: 'Laboratorio de Química', type: 'laboratorio', floor: 2, status: 'Disponible' },
  { id: 'lab-fisica', name: 'Laboratorio de Física', type: 'laboratorio', floor: 3, status: 'Ocupado' },
  { id: 'lab-biologia', name: 'Laboratorio de Biología', type: 'laboratorio', floor: 5, status: 'Disponible' },
  
  // Espacios especiales
  { id: 'auditorio-cine', name: 'Auditorio de Cine', type: 'auditorio', floor: 0, status: 'Disponible' },
  { id: 'biblioteca', name: 'Biblioteca', type: 'biblioteca', floor: 1, status: 'Ocupado' },
  { id: 'auditorio-idiomas', name: 'Auditorio de Idiomas', type: 'auditorio', floor: 2, status: 'Disponible' },
];

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate, userRole }) => {
  const [statusFilter, setStatusFilter] = useState('all');
  const [floorFilter, setFloorFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSpaces = spaces.filter(space => {
    const matchesStatus = statusFilter === 'all' || space.status === statusFilter;
    const matchesFloor = floorFilter === 'all' || space.floor.toString() === floorFilter;
    const matchesSearch = space.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesFloor && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex justify-between items-center mb-8">
          <h1>Disponibilidad de espacios académicos</h1>
          {userRole === 'admin' && (
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => onNavigate('aprobaciones')}
                className="flex items-center gap-2"
              >
                <Shield className="w-4 h-4" />
                Ver solicitudes pendientes
              </Button>
            </div>
          )}
        </div>

        {/* Filter Bar */}
        <div className="flex flex-wrap gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex gap-2">
            <motion.button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1 rounded-full text-sm transition-colors ${
                statusFilter === 'all' ? 'bg-primary text-white' : 'bg-white text-gray-600 hover:bg-gray-100'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Todos
            </motion.button>
            <motion.button
              onClick={() => setStatusFilter('Disponible')}
              className={`px-3 py-1 rounded-full text-sm transition-colors ${
                statusFilter === 'Disponible' ? 'bg-green-500 text-white' : 'bg-white text-gray-600 hover:bg-gray-100'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Disponible
            </motion.button>
            <motion.button
              onClick={() => setStatusFilter('Ocupado')}
              className={`px-3 py-1 rounded-full text-sm transition-colors ${
                statusFilter === 'Ocupado' ? 'bg-red-500 text-white' : 'bg-white text-gray-600 hover:bg-gray-100'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Ocupado
            </motion.button>
          </div>

          <Select value={floorFilter} onValueChange={setFloorFilter}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Piso" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="-1">Piso -1</SelectItem>
              <SelectItem value="0">Piso 0</SelectItem>
              <SelectItem value="1">Piso 1</SelectItem>
              <SelectItem value="2">Piso 2</SelectItem>
              <SelectItem value="3">Piso 3</SelectItem>
              <SelectItem value="4">Piso 4</SelectItem>
              <SelectItem value="5">Piso 5</SelectItem>
              <SelectItem value="6">Piso 6</SelectItem>
              <SelectItem value="7">Piso 7</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex gap-2">
            <Input type="date" className="w-40" />
            <Input type="time" className="w-32" />
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar salón, laboratorio o auditorio…"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Spaces Grid */}
        <ScrollArea className="h-[600px]">
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6"
            layout
          >
            {filteredSpaces.map((space, index) => (
              <motion.div
                key={space.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                whileHover={{ scale: 1.02 }}
                layout
              >
                <Card className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-base">{space.name}</CardTitle>
                      <Badge 
                        variant={space.status === 'Disponible' ? 'default' : 'destructive'}
                        className={space.status === 'Disponible' ? 'bg-green-500' : ''}
                      >
                        {space.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center text-sm text-gray-600">
                      <span>Piso {space.floor}</span>
                      <span className="capitalize">{space.type}</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </ScrollArea>

        {/* Nueva Solicitud Button */}
        <motion.div
          className="fixed bottom-8 right-8"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button 
            onClick={() => onNavigate('solicitudes')}
            size="lg"
            className="shadow-lg"
          >
            Nueva solicitud
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
};