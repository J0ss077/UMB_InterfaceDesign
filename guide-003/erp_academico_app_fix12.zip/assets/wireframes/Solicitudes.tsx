import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Checkbox } from './ui/checkbox';
import { AlertCircle } from 'lucide-react';

interface SolicitudesProps {
  onNavigate: (screen: string) => void;
}

const allSpaces = [
  // Salones
  ...Array.from({ length: 6 }, (_, i) => ({ id: `aula-${-101 - i}`, name: `Aula -${101 + i}`, floor: -1 })),
  ...Array.from({ length: 14 }, (_, i) => ({ id: `aula-${101 + i}`, name: `Aula ${101 + i}`, floor: 1 })),
  ...Array.from({ length: 14 }, (_, i) => ({ id: `aula-${201 + i}`, name: `Aula ${201 + i}`, floor: 2 })),
  ...Array.from({ length: 14 }, (_, i) => ({ id: `aula-${301 + i}`, name: `Aula ${301 + i}`, floor: 3 })),
  ...Array.from({ length: 14 }, (_, i) => ({ id: `aula-${401 + i}`, name: `Aula ${401 + i}`, floor: 4 })),
  ...Array.from({ length: 14 }, (_, i) => ({ id: `aula-${501 + i}`, name: `Aula ${501 + i}`, floor: 5 })),
  ...Array.from({ length: 10 }, (_, i) => ({ id: `aula-${601 + i}`, name: `Aula ${601 + i}`, floor: 6 })),
  ...Array.from({ length: 5 }, (_, i) => ({ id: `aula-${701 + i}`, name: `Aula ${701 + i}`, floor: 7 })),
  
  // Laboratorios
  { id: 'lab-quimica', name: 'Laboratorio de Química', floor: 2 },
  { id: 'lab-fisica', name: 'Laboratorio de Física', floor: 3 },
  { id: 'lab-biologia', name: 'Laboratorio de Biología', floor: 5 },
  
  // Espacios especiales
  { id: 'auditorio-cine', name: 'Auditorio de Cine', floor: 0 },
  { id: 'biblioteca', name: 'Biblioteca', floor: 1 },
  { id: 'auditorio-idiomas', name: 'Auditorio de Idiomas', floor: 2 },
];

const recursos = [
  'Microscopios',
  'Reactivos',
  'Proyector',
  'Sonido',
  'Cabinas'
];

export const Solicitudes: React.FC<SolicitudesProps> = ({ onNavigate }) => {
  const [formData, setFormData] = useState({
    docente: '',
    espacio: '',
    piso: '',
    franjaInicio: '',
    franjaFin: '',
    recursos: [] as string[]
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const filteredSpaces = formData.piso 
    ? allSpaces.filter(space => space.floor.toString() === formData.piso)
    : allSpaces;

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.docente.trim()) {
      newErrors.docente = 'El nombre del docente es requerido';
    }
    if (!formData.espacio) {
      newErrors.espacio = 'Debe seleccionar un espacio';
    }
    if (!formData.piso) {
      newErrors.piso = 'Debe seleccionar un piso';
    }
    if (!formData.franjaInicio) {
      newErrors.franjaInicio = 'Debe seleccionar hora de inicio';
    }
    if (!formData.franjaFin) {
      newErrors.franjaFin = 'Debe seleccionar hora de fin';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent, action: 'draft' | 'submit') => {
    e.preventDefault();
    
    if (action === 'submit' && !validateForm()) {
      // Shake animation for errors
      Object.keys(errors).forEach(field => {
        const element = document.getElementById(field);
        if (element) {
          element.classList.add('animate-shake');
          setTimeout(() => element.classList.remove('animate-shake'), 500);
        }
      });
      return;
    }

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (action === 'submit') {
      onNavigate('aprobaciones');
    } else {
      // Draft saved - show notification
      alert('Borrador guardado correctamente');
    }
    
    setIsSubmitting(false);
  };

  const handleResourceChange = (resource: string, checked: boolean) => {
    if (checked) {
      setFormData(prev => ({
        ...prev,
        recursos: [...prev.recursos, resource]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        recursos: prev.recursos.filter(r => r !== resource)
      }));
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="mb-8">Nueva solicitud</h1>

        <Card>
          <CardHeader>
            <CardTitle>Formulario de solicitud de espacio</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="space-y-6">
              {/* Docente */}
              <div className="space-y-2">
                <Label htmlFor="docente">Docente *</Label>
                <Input
                  id="docente"
                  value={formData.docente}
                  onChange={(e) => setFormData(prev => ({ ...prev, docente: e.target.value }))}
                  placeholder="Nombre del docente"
                  className={errors.docente ? 'border-red-500' : ''}
                />
                {errors.docente && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center gap-1 text-red-500 text-sm"
                  >
                    <AlertCircle className="w-4 h-4" />
                    {errors.docente}
                  </motion.div>
                )}
              </div>

              {/* Piso */}
              <div className="space-y-2">
                <Label htmlFor="piso">Piso *</Label>
                <Select 
                  value={formData.piso} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, piso: value, espacio: '' }))}
                >
                  <SelectTrigger id="piso" className={errors.piso ? 'border-red-500' : ''}>
                    <SelectValue placeholder="Seleccionar piso" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="-1">Piso -1</SelectItem>
                    <SelectItem value="0">Piso 0</SelectItem>
                    <SelectItem value="1">Piso 1</SelectItem>
                    <SelectItem value="2">Piso 2</SelectItem>
                    <SelectItem value="3">Piso 3</SelectItem>
                    <SelectItem value="4">Piso 4</SelectItem>
                    <SelectItem value="5">Piso 5</SelectItem>
                    <SelectItem value="6">Piso 6</SelectItem>
                    <SelectItem value="7">Piso 7</SelectItem>
                  </SelectContent>
                </Select>
                {errors.piso && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center gap-1 text-red-500 text-sm"
                  >
                    <AlertCircle className="w-4 h-4" />
                    {errors.piso}
                  </motion.div>
                )}
              </div>

              {/* Espacio */}
              <div className="space-y-2">
                <Label htmlFor="espacio">Espacio *</Label>
                <Select 
                  value={formData.espacio} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, espacio: value }))}
                  disabled={!formData.piso}
                >
                  <SelectTrigger id="espacio" className={errors.espacio ? 'border-red-500' : ''}>
                    <SelectValue placeholder="Seleccionar espacio" />
                  </SelectTrigger>
                  <SelectContent>
                    {filteredSpaces.map(space => (
                      <SelectItem key={space.id} value={space.id}>
                        {space.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.espacio && (
                  <motion.div
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center gap-1 text-red-500 text-sm"
                  >
                    <AlertCircle className="w-4 h-4" />
                    {errors.espacio}
                  </motion.div>
                )}
              </div>

              {/* Franja horaria */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="franjaInicio">Hora inicio *</Label>
                  <Input
                    id="franjaInicio"
                    type="time"
                    value={formData.franjaInicio}
                    onChange={(e) => setFormData(prev => ({ ...prev, franjaInicio: e.target.value }))}
                    className={errors.franjaInicio ? 'border-red-500' : ''}
                  />
                  {errors.franjaInicio && (
                    <motion.div
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center gap-1 text-red-500 text-sm"
                    >
                      <AlertCircle className="w-4 h-4" />
                      {errors.franjaInicio}
                    </motion.div>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="franjaFin">Hora fin *</Label>
                  <Input
                    id="franjaFin"
                    type="time"
                    value={formData.franjaFin}
                    onChange={(e) => setFormData(prev => ({ ...prev, franjaFin: e.target.value }))}
                    className={errors.franjaFin ? 'border-red-500' : ''}
                  />
                  {errors.franjaFin && (
                    <motion.div
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="flex items-center gap-1 text-red-500 text-sm"
                    >
                      <AlertCircle className="w-4 h-4" />
                      {errors.franjaFin}
                    </motion.div>
                  )}
                </div>
              </div>

              {/* Recursos */}
              <div className="space-y-3">
                <Label>Recursos adicionales</Label>
                <div className="grid grid-cols-2 gap-3">
                  {recursos.map(recurso => (
                    <div key={recurso} className="flex items-center space-x-2">
                      <Checkbox
                        id={recurso}
                        checked={formData.recursos.includes(recurso)}
                        onCheckedChange={(checked) => handleResourceChange(recurso, checked as boolean)}
                      />
                      <Label htmlFor={recurso} className="text-sm">{recurso}</Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-4 pt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={(e) => handleSubmit(e, 'draft')}
                  disabled={isSubmitting}
                  className="flex-1"
                >
                  Guardar borrador
                </Button>
                <Button
                  type="button"
                  onClick={(e) => handleSubmit(e, 'submit')}
                  disabled={isSubmitting}
                  className="flex-1"
                >
                  {isSubmitting ? 'Enviando...' : 'Enviar solicitud'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </motion.div>

      <style jsx>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
        .animate-shake {
          animation: shake 0.5s ease-in-out;
        }
      `}</style>
    </div>
  );
};