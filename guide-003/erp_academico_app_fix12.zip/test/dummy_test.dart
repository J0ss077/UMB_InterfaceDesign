import 'package:flutter_test/flutter_test.dart';

void main() {
  test('dummy', () {
    expect(2 + 2, 4);
  });
}
