import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:erp_wireframe_app/main.dart';

void main() {
  testWidgets('App shows ERP Académico title', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: ERPApp()));
    expect(find.text('ERP Académico'), findsOneWidget);
  });
}
