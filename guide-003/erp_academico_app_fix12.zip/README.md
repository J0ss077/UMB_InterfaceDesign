# ERP Académico (Flutter)

App demo para **asignación de salones** con dos roles: **Profesor** (solicita espacios)
y **Admin** (aprueba, prepara y confirma entregas).

## Rutas
- `/login`
- `/` ó `/dashboard` (salones con filtros + crear solicitud)
- `/solicitudes` (formulario de solicitud)
- `/aprobaciones` (solo Admin)
- `/preparacion` (solo Admin)
- `/confirmacion` (resumen de reserva)

## Ejecutar
```bash
flutter pub get
flutter create .
flutter run -d chrome
```
