class Room {
  final String id;
  final String name;
  final String type; // Salón, Laboratorio, Auditorio
  final int floor;
  final bool available;

  const Room({required this.id, required this.name, required this.type, required this.floor, required this.available});
}
