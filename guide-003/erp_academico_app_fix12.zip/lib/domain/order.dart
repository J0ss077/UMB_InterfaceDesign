enum OrderType { purchase, sale }

class OrderLine {
  final String productId;
  final int qty;
  final double unitPrice;
  const OrderLine({required this.productId, required this.qty, required this.unitPrice});
  double get lineTotal => qty * unitPrice;
}

class Order {
  final String id;
  final OrderType type;
  final DateTime date;
  final String partyName; // supplier or customer
  final List<OrderLine> lines;
  const Order({required this.id, required this.type, required this.date, required this.partyName, required this.lines});
  double get total => lines.fold(0, (sum, l) => sum + l.lineTotal);
}
