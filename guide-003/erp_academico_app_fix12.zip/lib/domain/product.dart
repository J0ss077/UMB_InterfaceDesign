class Product {
  final String id;
  final String sku;
  final String name;
  final String? description;
  final String unit;
  final double price;
  final int stock;

  const Product({
    required this.id,
    required this.sku,
    required this.name,
    this.description,
    required this.unit,
    required this.price,
    required this.stock,
  });

  Product copyWith({int? stock}) => Product(
        id: id,
        sku: sku,
        name: name,
        description: description,
        unit: unit,
        price: price,
        stock: stock ?? this.stock,
      );
}
