class Resource {
  final String name;
  final bool selected;
  const Resource(this.name, {this.selected = false});

  Resource copyWith({bool? selected}) => Resource(name, selected: selected ?? this.selected);
}

class ReservationRequest {
  final String id;
  final String teacher;
  final String roomName;
  final int floor;
  final DateTime date;
  final String timeRange; // '08:00 - 10:00'
  String status; // Pendiente, Aprobado, Rechazado
  final List<String> requestedResources;
  final String subject;
  final String notes;

  ReservationRequest({
    required this.id,
    required this.teacher,
    required this.roomName,
    required this.floor,
    required this.date,
    required this.timeRange,
    required this.status,
    required this.requestedResources,
    required this.subject,
    required this.notes,
  });
}
