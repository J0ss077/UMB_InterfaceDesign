import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:erp_wireframe_app/src/role_provider.dart';

class ShellScaffold extends ConsumerWidget {
  const ShellScaffold({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final role = ref.watch(userRoleProvider);
    final router = GoRouter.of(context);
    String path = GoRouterState.of(context).uri.toString();

    List<_TabItem> tabs = [
      _TabItem(label: 'Dashboard', route: '/'),
      _TabItem(label: 'Solicitudes', route: '/solicitudes'),
      if (role == UserRole.admin) _TabItem(label: 'Aprobaciones', route: '/aprobaciones'),
      if (role == UserRole.admin) _TabItem(label: 'Preparación', route: '/preparacion'),
    ];

    return Scaffold(
      appBar: AppBar(backgroundColor: const Color(0xFF3690E7), foregroundColor: Colors.white,
        title: const Text('ERP Académico'),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(children: [
              const Icon(Icons.verified_user, size: 18),
              const SizedBox(width: 6),
              Text(role == UserRole.admin ? 'Admin' : 'Usuario'),
              const SizedBox(width: 12),
              PopupMenuButton<String>(
                tooltip: 'Usuario',
                itemBuilder: (context) => [
                  const PopupMenuItem(value: 'prof', child: Text('Profesor')),
                  const PopupMenuItem(value: 'admin', child: Text('Admin')),
                ],
                onSelected: (v) {
                  ref.read(userRoleProvider.notifier).state = (v == 'admin') ? UserRole.admin : UserRole.profesor;
                  // keep same route, but hide if not allowed
                  if (ref.read(userRoleProvider) == UserRole.profesor && (path.startsWith('/aprobaciones') || path.startsWith('/preparacion'))) {
                    router.go('/');
                  } else {
                    router.go(path);
                  }
                },
                child: const Row(children: [Icon(Icons.person_outline), SizedBox(width: 4), Text('Usuario')]),
              ),
              const SizedBox(width: 8),
              TextButton.icon(
                onPressed: () => context.go('/login'),
                icon: const Icon(Icons.logout),
                label: const Text('Cerrar sesión'),
              ),
            ]),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Wrap(
              spacing: 12,
              children: [
                for (final t in tabs)
                  ChoiceChip(
                    label: Text(t.label),
                    selected: path == t.route || (t.route == '/' && (path == '/' || path == '/dashboard')),
                    onSelected: (_) => context.go(t.route),
                  ),
              ],
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: child,
      ),
    );
  }
}

class _TabItem {
  final String label;
  final String route;
  _TabItem({required this.label, required this.route});
}
