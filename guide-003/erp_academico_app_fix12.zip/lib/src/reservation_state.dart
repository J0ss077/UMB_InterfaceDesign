import 'package:flutter_riverpod/flutter_riverpod.dart';

class ReservationReceipt {
  final String id;
  final String teacher;
  final String room;
  final int floor;
  final DateTime date;
  final String timeRange;
  final List<String> resources;
  const ReservationReceipt({
    required this.id,
    required this.teacher,
    required this.room,
    required this.floor,
    required this.date,
    required this.timeRange,
    required this.resources,
  });
}

final lastReservationProvider = StateProvider<ReservationReceipt?>((ref) => null);

class ReservationSeq {
  static int _n = 1;
  static String nextId() {
    final n = _n++;
    return 'SOL-${n.toString().padLeft(3, '0')}';
  }
}
