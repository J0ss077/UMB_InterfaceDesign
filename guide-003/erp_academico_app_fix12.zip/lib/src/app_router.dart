import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:erp_wireframe_app/features/auth/login_screen.dart';
import 'package:erp_wireframe_app/features/rooms/dashboard_screen.dart';
import 'package:erp_wireframe_app/features/requests/requests_screen.dart';
import 'package:erp_wireframe_app/features/approvals/approvals_screen.dart';
import 'package:erp_wireframe_app/features/preparation/preparation_screen.dart';
import 'package:erp_wireframe_app/features/confirmation/confirmation_screen.dart';
import 'package:erp_wireframe_app/shared/layout/shell_scaffold.dart';
import 'package:erp_wireframe_app/src/role_provider.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/',
    routes: [
      GoRoute(
        path: '/login',
        name: 'login',
        builder: (context, state) => const LoginScreen(),
      ),
      ShellRoute(
        builder: (context, state, child) => ShellScaffold(child: child),
        routes: [
          GoRoute(
            path: '/',
            name: 'dashboard',
            builder: (context, state) => const DashboardScreen(),
          ),
          GoRoute(
            path: '/dashboard',
            name: 'dashboard2',
            builder: (context, state) => const DashboardScreen(),
          ),
          GoRoute(
            path: '/solicitudes',
            name: 'solicitudes',
            builder: (context, state) => const RequestsScreen(),
          ),
          GoRoute(
            path: '/aprobaciones',
            name: 'aprobaciones',
            builder: (context, state) => const ApprovalsScreen(),
          ),
          GoRoute(
            path: '/preparacion',
            name: 'preparacion',
            builder: (context, state) => const PreparationScreen(),
          ),
          GoRoute(
            path: '/confirmacion',
            name: 'confirmacion',
            builder: (context, state) => const ConfirmationScreen(),
          ),
          GoRoute(
            path: '/mi-reserva',
            name: 'mireserva',
            builder: (context, state) => const ConfirmationScreen(),
          ),
        ],
      ),
    ],
    redirect: (context, state) {
      final role = ref.read(userRoleProvider);
      // If profesor tries to access admin routes, send to dashboard
      final uri = state.uri.toString();
      final isAdminOnly = uri.startsWith('/aprobaciones') || uri.startsWith('/preparacion');
      final isUserOnly = uri.startsWith('/confirmacion');
      if (role == UserRole.profesor && isAdminOnly) {
        return '/';
      }
      if (role == UserRole.admin && isUserOnly) {
        return '/';
      }
      return null;
    },
    errorBuilder: (context, state) => Scaffold(
      body: Center(child: Text('404 Not Found: ${state.uri}')),
    ),
  );
});
