import 'package:flutter/material.dart';

/// Shows a dial time picker but **only uses the HOUR**; minutes are forced to :00.
/// [use24h] toggles 24-hour display (web/desktop usually true).
Future<TimeOfDay?> pickHourDial(BuildContext context, {required TimeOfDay initial, bool use24h = false}) async {
  final picked = await showTimePicker(
    context: context,
    initialTime: initial,
    initialEntryMode: TimePickerEntryMode.dial,
    helpText: 'Selecciona solo la HORA (los minutos se fijan en :00)',
    builder: (context, child) {
      if (use24h) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: true),
          child: child!,
        );
      }
      return child!;
    },
  );
  if (picked == null) return null;
  // Force minutes to 0 regardless of selection.
  return TimeOfDay(hour: picked.hour, minute: 0);
}
