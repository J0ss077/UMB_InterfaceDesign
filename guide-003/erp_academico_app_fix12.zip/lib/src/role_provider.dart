import 'package:flutter_riverpod/flutter_riverpod.dart';

enum UserRole { profesor, admin }

final userRoleProvider = StateProvider<UserRole>((ref) => UserRole.profesor);
