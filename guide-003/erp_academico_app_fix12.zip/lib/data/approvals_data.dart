import '../domain/reservation.dart';

class ApprovalsData {
  static final requests = <ReservationRequest>[
    ReservationRequest(
      id: 'SOL-001',
      teacher: 'Dr. María González',
      roomName: 'Aula 201',
      floor: 2,
      date: DateTime(2024, 9, 15),
      timeRange: '08:00 - 10:00',
      status: 'Pendiente',
      requestedResources: ['Proyector', 'Sonido'],
      subject: 'Matemáticas Avanzadas',
      notes: 'Clase magistral con presentación multimedia',
    ),
    ReservationRequest(
      id: 'SOL-002',
      teacher: 'Prof. Carlos Ruiz',
      roomName: 'Laboratorio de Química',
      floor: 2,
      date: DateTime(2024, 9, 16),
      timeRange: '14:00 - 16:00',
      status: 'Pendiente',
      requestedResources: ['Proyector'],
      subject: 'Química I',
      notes: 'Necesita campanas de extracción',
    ),
    ReservationRequest(
      id: 'SOL-003',
      teacher: 'Dra. Ana López',
      roomName: 'Auditorio de Cine',
      floor: 0,
      date: DateTime(2024, 9, 17),
      timeRange: '10:00 - 12:00',
      status: 'Aprobado',
      requestedResources: ['Sonido'],
      subject: 'Seminario audiovisual',
      notes: '',
    ),
  ];
}
