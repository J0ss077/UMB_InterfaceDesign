import '../domain/room.dart';

class RoomsData {
  static List<Room> build() {
    final list = <Room>[];

    // Piso -1: Aulas -101..-106
    for (int n = 101; n <= 106; n++) {
      list.add(Room(id: 'R--$n', name: 'Aula -$n', type: 'Salón', floor: -1, available: n % 3 != 0));
    }

    // Helper to add ranges like 101..114 for floors 1..5 etc.
    void addRange(int floor, int start, int end) {
      for (int n = start; n <= end; n++) {
        list.add(Room(id: 'R-$n', name: 'Aula $n', type: 'Salón', floor: floor, available: n % 4 != 0));
      }
    }

    // Piso 1: 101..114
    addRange(1, 101, 114);
    // Piso 2: 201..214
    addRange(2, 201, 214);
    // Piso 3: 301..314
    addRange(3, 301, 314);
    // Piso 4: 401..414
    addRange(4, 401, 414);
    // Piso 5: 501..514
    addRange(5, 501, 514);
    // Piso 6: 601..610
    addRange(6, 601, 610);
    // Piso 7: 701..705
    addRange(7, 701, 705);

    // Laboratorios y Auditorios (se agrupan como 'Otros')
    list.addAll([
      Room(id: 'LAB-QUI', name: 'Laboratorio de Química', type: 'Otros', floor: 2, available: true),
      Room(id: 'LAB-BIO', name: 'Laboratorio de Biología', type: 'Otros', floor: 5, available: true),
      Room(id: 'AUD-CINE', name: 'Auditorio de Cine', type: 'Otros', floor: 3, available: true),
      Room(id: 'AUD-MAG', name: 'Auditorio Magno', type: 'Otros', floor: 7, available: false),
    ]);

    return list;
  }

  static final rooms = build();
}
