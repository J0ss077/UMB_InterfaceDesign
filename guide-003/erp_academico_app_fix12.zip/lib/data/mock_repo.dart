import 'dart:math';
import '../domain/product.dart';
import '../domain/order.dart';

class MockRepo {
  static final _rnd = Random(42);

  static List<Product> products = List.generate(24, (i) {
    return Product(
      id: 'P${i+1}',
      sku: 'SKU-${1000 + i}',
      name: 'Producto ${i+1}',
      description: 'Descripción del producto ${i+1}',
      unit: 'ud',
      price: (10 + i) * 1.25,
      stock: 10 + _rnd.nextInt(250),
    );
  });

  static List<Order> purchaseOrders = List.generate(10, (i) {
    return Order(
      id: 'OC-${2000 + i}',
      type: OrderType.purchase,
      date: DateTime.now().subtract(Duration(days: i * 3)),
      partyName: 'Proveedor ${i+1}',
      lines: [
        OrderLine(productId: products[i].id, qty: 5 + i, unitPrice: products[i].price * 0.9),
        OrderLine(productId: products[i+1].id, qty: 2 + i, unitPrice: products[i+1].price * 0.9),
      ],
    );
  });

  static List<Order> salesOrders = List.generate(12, (i) {
    return Order(
      id: 'PV-${3000 + i}',
      type: OrderType.sale,
      date: DateTime.now().subtract(Duration(days: i * 2)),
      partyName: 'Cliente ${i+1}',
      lines: [
        OrderLine(productId: products[i].id, qty: 1 + i, unitPrice: products[i].price * 1.1),
      ],
    );
  });
}
