import 'package:flutter/material.dart';
import '../../data/mock_repo.dart';
import '../../domain/order.dart';

class PurchaseOrdersScreen extends StatelessWidget {
  const PurchaseOrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final orders = MockRepo.purchaseOrders;
    return Card(
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: DataTable(
          columns: const [
            DataColumn(label: Text('OC')),
            DataColumn(label: Text('Fecha')),
            DataColumn(label: Text('Proveedor')),
            DataColumn(label: Text('Líneas')),
            DataColumn(label: Text('Total')),
          ],
          rows: [
            for (final o in orders)
              DataRow(cells: [
                DataCell(Text(o.id)),
                DataCell(Text(o.date.toLocal().toString().split('.').first)),
                DataCell(Text(o.partyName)),
                DataCell(Text(o.lines.length.toString())),
                DataCell(Text(o.total.toStringAsFixed(2))),
              ]),
          ],
        ),
      ),
    );
  }
}
