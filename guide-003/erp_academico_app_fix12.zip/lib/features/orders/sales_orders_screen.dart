import 'package:flutter/material.dart';
import '../../data/mock_repo.dart';

class SalesOrdersScreen extends StatelessWidget {
  const SalesOrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final orders = MockRepo.salesOrders;
    return Card(
      child: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: DataTable(
          columns: const [
            DataColumn(label: Text('Venta')),
            DataColumn(label: Text('Fecha')),
            DataColumn(label: Text('Cliente')),
            DataColumn(label: Text('Líneas')),
            DataColumn(label: Text('Total')),
          ],
          rows: [
            for (final o in orders)
              DataRow(cells: [
                DataCell(Text(o.id)),
                DataCell(Text(o.date.toLocal().toString().split('.').first)),
                DataCell(Text(o.partyName)),
                DataCell(Text(o.lines.length.toString())),
                DataCell(Text(o.total.toStringAsFixed(2))),
              ]),
          ],
        ),
      ),
    );
  }
}
