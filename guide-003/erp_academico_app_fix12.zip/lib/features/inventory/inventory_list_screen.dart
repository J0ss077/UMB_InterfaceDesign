import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../data/mock_repo.dart';

class InventoryListScreen extends StatefulWidget {
  const InventoryListScreen({super.key});

  @override
  State<InventoryListScreen> createState() => _InventoryListScreenState();
}

class _InventoryListScreenState extends State<InventoryListScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final items = MockRepo.products
        .where((p) => p.name.toLowerCase().contains(_query.toLowerCase()) || p.sku.toLowerCase().contains(_query.toLowerCase()))
        .toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: TextField(
                decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Buscar SKU o nombre...'),
                onChanged: (v) => setState(() => _query = v),
              ),
            ),
            const SizedBox(width: 12),
            ElevatedButton.icon(onPressed: () {}, icon: const Icon(Icons.file_download), label: const Text('Exportar')),
          ],
        ),
        const SizedBox(height: 12),
        Expanded(
          child: Card(
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('SKU')),
                  DataColumn(label: Text('Producto')),
                  DataColumn(label: Text('Unidad')),
                  DataColumn(label: Text('Precio')),
                  DataColumn(label: Text('Stock')),
                  DataColumn(label: Text('')),
                ],
                rows: [
                  for (final p in items)
                    DataRow(cells: [
                      DataCell(Text(p.sku)),
                      DataCell(Text(p.name)),
                      DataCell(Text(p.unit)),
                      DataCell(Text('\${p.price.toStringAsFixed(2)}')),
                      DataCell(Text(p.stock.toString())),
                      DataCell(
                        TextButton(
                          onPressed: () => context.go('/inventory/item/${p.id}'),
                          child: const Text('Ver'),
                        ),
                      ),
                    ]),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
