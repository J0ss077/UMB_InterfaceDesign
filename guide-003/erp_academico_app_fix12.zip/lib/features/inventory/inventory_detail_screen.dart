import 'package:flutter/material.dart';
import '../../data/mock_repo.dart';

class InventoryDetailScreen extends StatelessWidget {
  const InventoryDetailScreen({super.key, required this.id});
  final String id;

  @override
  Widget build(BuildContext context) {
    final product = MockRepo.products.firstWhere((p) => p.id == id);
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(product.name, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Wrap(spacing: 16, runSpacing: 16, children: [
            _InfoCard(title: 'SKU', value: product.sku),
            _InfoCard(title: 'Unidad', value: product.unit),
            _InfoCard(title: 'Precio', value: '\${product.price.toStringAsFixed(2)}'),
            _InfoCard(title: 'Stock', value: product.stock.toString()),
          ]),
          const SizedBox(height: 16),
          Text('Descripción', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(product.description ?? '-'),
          const SizedBox(height: 16),
          Row(
            children: [
              ElevatedButton.icon(onPressed: () {}, icon: const Icon(Icons.edit), label: const Text('Editar')),
              const SizedBox(width: 8),
              OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.history), label: const Text('Movimientos')),
            ],
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.title, required this.value});
  final String title;
  final String value;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 220,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: Theme.of(context).textTheme.labelLarge),
            const SizedBox(height: 8),
            Text(value, style: Theme.of(context).textTheme.titleLarge),
          ]),
        ),
      ),
    );
  }
}
