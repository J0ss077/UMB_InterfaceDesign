import 'package:flutter/material.dart';
import 'package:erp_wireframe_app/data/approvals_data.dart';
import 'package:erp_wireframe_app/domain/reservation.dart';

class ApprovalsScreen extends StatefulWidget {
  const ApprovalsScreen({super.key});

  @override
  State<ApprovalsScreen> createState() => _ApprovalsScreenState();
}

class _ApprovalsScreenState extends State<ApprovalsScreen> {
  final Set<String> _expanded = {};

  @override
  Widget build(BuildContext context) {
    final items = ApprovalsData.requests;

    DataRow _row(ReservationRequest r) {
      return DataRow(cells: [
        DataCell(Row(children: [
          IconButton(
            icon: Icon(_expanded.contains(r.id) ? Icons.keyboard_arrow_down : Icons.keyboard_arrow_right),
            onPressed: () => setState(() { _expanded.contains(r.id) ? _expanded.remove(r.id) : _expanded.add(r.id); }),
          ),
          SelectableText(r.id, style: const TextStyle(fontWeight: FontWeight.bold)),
        ])),
        DataCell(Text(r.teacher)),
        DataCell(Text(r.roomName)),
        DataCell(Text('${r.floor}')),
        DataCell(Text(r.timeRange)),
        DataCell(_statusChip(r.status)),
        DataCell(Row(children: [
          OutlinedButton(
            onPressed: () => setState(() => r.status = 'Rechazado'),
            style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Rechazar'),
          ),
          const SizedBox(width: 8),
          ElevatedButton(
            onPressed: () => setState(() => r.status = 'Aprobado'),
            child: const Text('Aprobar'),
          ),
        ])),
      ]);
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Aprobación de solicitudes', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        Card(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: DataTable(
              columns: const [
                DataColumn(label: Text('ID')),
                DataColumn(label: Text('Solicitante')),
                DataColumn(label: Text('Espacio')),
                DataColumn(label: Text('Piso')),
                DataColumn(label: Text('Franja')),
                DataColumn(label: Text('Estado')),
                DataColumn(label: Text('Acciones')),
              ],
              rows: [
                for (final r in items) _row(r),
                // Expanded details row(s)
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        for (final r in items.where((e) => _expanded.contains(e.id)))
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            child: _DetailCard(r: r),
          ),
      ],
    );
  }

  Widget _statusChip(String status) {
    Color bg;
    Color fg;
    switch (status) {
      case 'Aprobado':
        bg = Colors.green.shade100; fg = Colors.green.shade800; break;
      case 'Rechazado':
        bg = Colors.red.shade100; fg = Colors.red.shade800; break;
      default:
        bg = Colors.amber.shade100; fg = Colors.amber.shade800;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(999)),
      child: Text(status, style: TextStyle(color: fg)),
    );
  }
}

class _DetailCard extends StatelessWidget {
  const _DetailCard({required this.r});
  final ReservationRequest r;
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Icon(Icons.menu_book_outlined, size: 18),
              const SizedBox(width: 8),
              Text('Materia', style: Theme.of(context).textTheme.titleSmall),
            ]),
            Text(r.subject),
            const SizedBox(height: 8),
            Row(children: [
              const Icon(Icons.schedule, size: 18),
              const SizedBox(width: 8),
              Text('Fecha', style: Theme.of(context).textTheme.titleSmall),
            ]),
            Text(r.date.toString().substring(0,10)),
            const SizedBox(height: 8),
            Row(children: [
              const Icon(Icons.location_on_outlined, size: 18),
              const SizedBox(width: 8),
              Text('Estudiantes', style: Theme.of(context).textTheme.titleSmall),
            ]),
            const Text('35'),
            const SizedBox(height: 8),
            Text('Recursos solicitados'),
            Wrap(spacing: 8, children: [for (final rsc in r.requestedResources) Chip(label: Text(rsc))]),
            const SizedBox(height: 8),
            Text('Observaciones'),
            Text(r.notes.isEmpty ? '-' : r.notes),
          ],
        ),
      ),
    );
  }
}
