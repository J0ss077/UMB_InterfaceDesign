import 'package:erp_wireframe_app/src/time_picker.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:erp_wireframe_app/data/rooms_data.dart';
import 'package:erp_wireframe_app/domain/room.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String statusFilter = 'Todo'; // Todo, Disponible, Ocupado
  String typeFilter = 'Todos'; // Todos, Salón, Otros
  String query = '';
  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  @override
  Widget build(BuildContext context) {
    final rooms = RoomsData.rooms.where((r) {
      final matchesStatus = statusFilter == 'Todo' ||
          (statusFilter == 'Disponible' && r.available) ||
          (statusFilter == 'Ocupado' && !r.available);
      final matchesType = typeFilter == 'Todos' || r.type == typeFilter;
      final matchesQuery = r.name.toLowerCase().contains(query.toLowerCase());
      return matchesStatus && matchesType && matchesQuery;
    }).toList();

    return Stack(
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                SizedBox(
                  width: 200,
                  child: DropdownButtonFormField<String>(
                    value: typeFilter,
                    decoration: const InputDecoration(labelText: 'Tipo'),
                    items: const [
                      DropdownMenuItem(value: 'Todos', child: Text('Todos')),
                      DropdownMenuItem(value: 'Salón', child: Text('Salón')),
                      DropdownMenuItem(value: 'Otros', child: Text('Otros (Laboratorios/Auditorios)')),
                    ],
                    onChanged: (v) => setState(() => typeFilter = v ?? 'Todos'),
                  ),
                ),
                SizedBox(
                  width: 200,
                  child: DropdownButtonFormField<String>(
                    value: statusFilter,
                    decoration: const InputDecoration(labelText: 'Estado'),
                    items: const [
                      DropdownMenuItem(value: 'Todo', child: Text('Todo')),
                      DropdownMenuItem(value: 'Disponible', child: Text('Disponible')),
                      DropdownMenuItem(value: 'Ocupado', child: Text('Ocupado')),
                    ],
                    onChanged: (v) => setState(() => statusFilter = v ?? 'Todo'),
                  ),
                ),
                SizedBox(
                  width: 520,
                  child: TextField(
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      hintText: 'Buscar salón, laboratorio o auditorio...',
                    ),
                    onChanged: (v) => setState(() => query = v),
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 180,
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final now = DateTime.now();
                          final picked = await showDatePicker(
                            context: context,
                            firstDate: DateTime(now.year - 1),
                            lastDate: DateTime(now.year + 1),
                            initialDate: selectedDate ?? now,
                          );
                          if (picked != null) setState(() => selectedDate = picked);
                        },
                        icon: const Icon(Icons.calendar_today_outlined),
                        label: Text(selectedDate == null
                            ? 'dd/mm/aaaa'
                            : DateFormat('dd/MM/yyyy').format(selectedDate!)),
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 160,
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await pickHourDial(
                            context,
                            initial: selectedTime ?? TimeOfDay.now(),
                            use24h: true,
                          );
                          if (picked != null) setState(() => selectedTime = picked);
                        },
                        icon: const Icon(Icons.access_time),
                        label: Text(selectedTime == null
                            ? '--:-- -----'
                            : selectedTime!.format(context)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  childAspectRatio: 4,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 12,
                ),
                itemCount: rooms.length,
                itemBuilder: (context, i) {
                  final r = rooms[i];
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(r.name, style: Theme.of(context).textTheme.titleMedium),
                                const SizedBox(height: 6),
                                Text('Piso ${r.floor}', style: Theme.of(context).textTheme.bodySmall),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: r.available ? Colors.green.shade100 : Colors.red.shade100,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              r.available ? 'Disponible' : 'Ocupado',
                              style: TextStyle(
                                color: r.available ? Colors.green.shade900 : Colors.red.shade900,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
        Positioned(
          bottom: 16,
          right: 16,
          child: FloatingActionButton.extended(
            onPressed: () => context.go('/solicitudes'),
            label: const Text('Nueva solicitud'),
            icon: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }
}
