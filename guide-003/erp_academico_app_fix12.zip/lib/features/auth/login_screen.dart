import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:erp_wireframe_app/src/role_provider.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController(text: '');
  final _password = TextEditingController(text: '');
  bool _adminSelected = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Card(
                elevation: 0,
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        const CircleAvatar(radius: 28, child: Icon(Icons.person)),
                        const SizedBox(height: 12),
                        Text('ERP Académico', style: theme.textTheme.titleLarge),
                        const SizedBox(height: 4),
                        Text('Gestión de espacios académicos', style: theme.textTheme.bodyMedium),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _email,
                          decoration: const InputDecoration(labelText: 'Correo electrónico', hintText: 'nombre@academia.umb.edu.co'),
                          validator: (v) => (v==null || v.isEmpty) ? 'Requerido' : null,
                        ),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: _password,
                          obscureText: true,
                          decoration: const InputDecoration(labelText: 'Contraseña'),
                          validator: (v) => (v==null || v.isEmpty) ? 'Requerido' : null,
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                ref.read(userRoleProvider.notifier).state = _adminSelected ? UserRole.admin : UserRole.profesor;
                                context.go('/');
                              }
                            },
                            child: const Text('Iniciar sesión'),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text('Credenciales de demostración:' , style: theme.textTheme.bodySmall),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ChoiceChip(
                              label: const Row(children: [Icon(Icons.school, size: 18), SizedBox(width: 6), Text('Profesor Demo')]),
                              selected: !_adminSelected,
                              onSelected: (v) {
                                setState(() {
                                  _adminSelected = false;
                                  _email.text = 'profesor@academia.umb.edu.co';
                                  _password.text = 'profesor123';
                                });
                              },
                            ),
                            const SizedBox(width: 12),
                            ChoiceChip(
                              label: const Row(children: [Icon(Icons.admin_panel_settings, size: 18), SizedBox(width: 6), Text('Admin Demo')]),
                              selected: _adminSelected,
                              onSelected: (v) {
                                setState(() {
                                  _adminSelected = true;
                                  _email.text = 'admin@academia.umb.edu.co';
                                  _password.text = 'admin';
                                });
                              },
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text('• Profesor: profesor@academia.umb.edu.co / profesor123\n• Admin: admin@academia.umb.edu.co / admin',
                              style: theme.textTheme.bodySmall),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                elevation: 0,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Text('Sistema ERP Académico UMB', style: theme.textTheme.titleMedium),
                      const SizedBox(height: 8),
                      Text('Use su correo institucional para acceder al sistema', style: theme.textTheme.bodySmall),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
