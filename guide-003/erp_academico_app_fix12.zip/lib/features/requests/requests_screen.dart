import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:erp_wireframe_app/data/rooms_data.dart';
import 'package:erp_wireframe_app/domain/room.dart';
import 'package:erp_wireframe_app/src/time_picker.dart';
import 'package:erp_wireframe_app/src/reservation_state.dart';
import 'package:intl/intl.dart';

class RequestsScreen extends ConsumerStatefulWidget {
  const RequestsScreen({super.key});

  @override
  ConsumerState<RequestsScreen> createState() => _RequestsScreenState();
}

class _RequestsScreenState extends ConsumerState<RequestsScreen> {
  final _formKey = GlobalKey<FormState>();
  final _teacher = TextEditingController();
  Room? _selectedRoom;
  int? _selectedFloor;
  TimeOfDay? _start;
  TimeOfDay? _end;
  DateTime? _date;

  final resources = {
    'Microscopios': false,
    'Proyector': false,
    'Cabinas': false,
    'Reactivos': false,
    'Sonido': false,
  };

  @override
  Widget build(BuildContext context) {
    final floors = RoomsData.rooms.map((r) => r.floor).toSet().toList()..sort();
    final roomsByFloor = (_selectedFloor == null)
        ? <Room>[]
        : RoomsData.rooms.where((r) => r.floor == _selectedFloor).toList();

    return SingleChildScrollView(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 860),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Nueva solicitud', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text('Formulario de solicitud de espacio', style: Theme.of(context).textTheme.titleMedium),
                        ),
                        const SizedBox(height: 16),
                        TextFormField(
                          controller: _teacher,
                          decoration: const InputDecoration(labelText: 'Docente *', hintText: 'Nombre del docente'),
                          validator: (v) => (v == null || v.isEmpty) ? 'Requerido' : null,
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: DropdownButtonFormField<int>(
                                value: _selectedFloor,
                                items: [for (final f in floors) DropdownMenuItem(value: f, child: Text('Piso $f'))],
                                decoration: const InputDecoration(labelText: 'Piso *'),
                                onChanged: (v) => setState(() {
                                  _selectedFloor = v;
                                  _selectedRoom = null;
                                }),
                                validator: (v) => (v == null) ? 'Seleccione piso' : null,
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: DropdownButtonFormField<Room>(
                                value: _selectedRoom,
                                items: [for (final r in roomsByFloor) DropdownMenuItem(value: r, child: Text(r.name))],
                                decoration: const InputDecoration(labelText: 'Espacio *'),
                                onChanged: (v) => setState(() => _selectedRoom = v),
                                validator: (v) => (v == null) ? 'Seleccione espacio' : null,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton.icon(
                                icon: const Icon(Icons.calendar_today),
                                label: Text(_date == null ? 'Fecha *' : DateFormat('yyyy-MM-dd').format(_date!)),
                                onPressed: () async {
                                  final now = DateTime.now();
                                  final picked = await showDatePicker(
                                    context: context,
                                    firstDate: now.subtract(const Duration(days: 1)),
                                    lastDate: now.add(const Duration(days: 365)),
                                    initialDate: _date ?? now,
                                  );
                                  if (picked != null) setState(() => _date = picked);
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: OutlinedButton.icon(
                                icon: const Icon(Icons.schedule),
                                label: Text(_start == null ? 'Hora inicio *' : _start!.format(context)),
                                onPressed: () async {
                                  final picked = await pickHourDial(
                                    context,
                                    initial: _start ?? TimeOfDay.now(),
                                    use24h: true,
                                  );
                                  if (picked != null) setState(() => _start = picked);
                                },
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: OutlinedButton.icon(
                                icon: const Icon(Icons.schedule),
                                label: Text(_end == null ? 'Hora fin *' : _end!.format(context)),
                                onPressed: () async {
                                  final picked = await pickHourDial(
                                    context,
                                    initial: _end ?? TimeOfDay.now(),
                                    use24h: true,
                                  );
                                  if (picked != null) setState(() => _end = picked);
                                },
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text('Recursos adicionales', style: Theme.of(context).textTheme.titleMedium),
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 12,
                          children: resources.keys
                              .map((k) => CheckboxListTile(
                                    value: resources[k],
                                    onChanged: (v) => setState(() => resources[k] = v ?? false),
                                    title: Text(k),
                                    controlAffinity: ListTileControlAffinity.leading,
                                    dense: true,
                                  ))
                              .toList(),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            OutlinedButton.icon(
                              onPressed: () {},
                              icon: const Icon(Icons.save_outlined),
                              label: const Text('Guardar borrador'),
                            ),
                            const SizedBox(width: 12),
                            ElevatedButton.icon(
                              onPressed: () {
                                if (_formKey.currentState!.validate() && _date != null && _start != null && _end != null) {
                                  final id = ReservationSeq.nextId();
                                  final timeRange = '${_start!.format(context)} - ${_end!.format(context)}';
                                  final selectedResources = resources.entries
                                      .where((e) => e.value)
                                      .map((e) => e.key)
                                      .toList();
                                  final receipt = ReservationReceipt(
                                    id: id,
                                    teacher: _teacher.text,
                                    room: _selectedRoom!.name,
                                    floor: _selectedFloor!,
                                    date: _date!,
                                    timeRange: timeRange,
                                    resources: selectedResources,
                                  );
                                  ref.read(lastReservationProvider.notifier).state = receipt;
                                  context.go('/confirmacion');
                                } else {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Complete los campos requeridos')),
                                  );
                                }
                              },
                              icon: const Icon(Icons.send),
                              label: const Text('Enviar solicitud'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
