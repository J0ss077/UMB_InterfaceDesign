import 'package:flutter/material.dart';

class PreparationScreen extends StatelessWidget {
  const PreparationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Preparación y entrega', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Progreso de la orden', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  Row(
                    children: const [
                      _Step(icon: Icons.inventory_2, label: 'Orden creada', active: true),
                      SizedBox(width: 24),
                      _Step(icon: Icons.access_time, label: 'Preparando', active: true),
                      SizedBox(width: 24),
                      _Step(icon: Icons.check_circle_outline, label: 'Listo', active: false),
                      SizedBox(width: 24),
                      _Step(icon: Icons.local_shipping, label: 'Entregado', active: false),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text('Progreso general'),
                  const SizedBox(height: 6),
                  const LinearProgressIndicator(value: 0.4),
                  const SizedBox(height: 8),
                  Align(alignment: Alignment.centerRight, child: Text('40%')),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text('Recursos en preparación', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          const _ResourceCard(title: 'Microscopios x3', location: 'Aula 201 • Ana García', progress: 0.85, tag: 'Preparando', eta: '5 min restantes'),
          const _ResourceCard(title: 'Proyector 4K', location: 'Auditorio Cine • Carlos López', progress: 1.0, tag: 'Listo', eta: 'Completado'),
          const _ResourceCard(title: 'Sistema de Sonido', location: 'Auditorio Cine • María González', progress: 0.6, tag: 'Preparando', eta: '15 min restantes'),
          const SizedBox(height: 16),
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(color: Colors.lightBlue.shade100, borderRadius: BorderRadius.circular(8)),
              child: const Text('Esperando preparación...'),
            ),
          ),
          const SizedBox(height: 16),
          Wrap(spacing: 16, children: const [
            _StatCard(value: '3', label: 'Listos'),
            _StatCard(value: '1', label: 'En preparación'),
            _StatCard(value: '1', label: 'Pendientes'),
          ]),
        ],
      ),
    );
  }
}

class _Step extends StatelessWidget {
  const _Step({required this.icon, required this.label, required this.active});
  final IconData icon;
  final String label;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      CircleAvatar(backgroundColor: active ? Colors.green.shade100 : Colors.grey.shade200, child: Icon(icon, color: active ? Colors.green.shade800 : Colors.grey.shade600)),
      const SizedBox(width: 8),
      Text(label),
    ]);
  }
}

class _ResourceCard extends StatelessWidget {
  const _ResourceCard({required this.title, required this.location, required this.progress, required this.tag, required this.eta});
  final String title;
  final String location;
  final double progress;
  final String tag;
  final String eta;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: Theme.of(context).textTheme.titleMedium),
          Text(location, style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 8),
          const Text('Progreso'),
          const SizedBox(height: 4),
          LinearProgressIndicator(value: progress),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _ChipTag(text: tag, color: tag == 'Listo' ? Colors.green : Colors.blue),
              Text(eta),
            ],
          ),
        ]),
      ),
    );
  }
}

class _ChipTag extends StatelessWidget {
  const _ChipTag({required this.text, required this.color});
  final String text;
  final MaterialColor color;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(999)),
      child: Text(text, style: TextStyle(color: color.shade700)),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.value, required this.label});
  final String value;
  final String label;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 220,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(children: [
            Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.green)),
            Text(label),
          ]),
        ),
      ),
    );
  }
}
