 // ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:erp_wireframe_app/src/reservation_state.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ConfirmationScreen extends ConsumerWidget {
  const ConfirmationScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('¡Solicitud completada!', style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.green.shade700)),
          const SizedBox(height: 8),
          Text('El espacio ha sido reservado y la entrega registrada.'),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(child: Icon(Icons.check_circle, size: 72, color: Colors.green.shade600)),
                  const SizedBox(height: 16),
                  Text('Resumen de la reserva', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  Wrap(spacing: 24, runSpacing: 12, children: const [
                    _KV(label: 'Docente', value: 'Dr. María González'),
                    _KV(label: 'Fecha', value: '15 de Septiembre, 2024'),
                    _KV(label: 'Espacio', value: 'Aula 201'),
                    _KV(label: 'Horario', value: '08:00 - 10:00'),
                  ]),
                  const SizedBox(height: 12),
                  Text('Recursos entregados'),
                  Wrap(spacing: 8, children: [
                    for (final r in (ref.watch(lastReservationProvider))?.resources ?? const ['Microscopios x3','Proyector 4K','Sistema de Sonido'])
                      Chip(label: Text('✓ ' + r)),
                  ]),
                  const SizedBox(height: 16),
                  Text('Número de referencia'),
                  InkWell(
                    onTap: () => context.go('/mi-reserva'),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: Colors.blue.shade50, borderRadius: BorderRadius.circular(8)),
                      child: (Text(ref.watch(lastReservationProvider)?.id ?? 'SOL-001', style: const TextStyle(decoration: TextDecoration.underline))),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      ElevatedButton(onPressed: () => context.go('/'), child: const Text('Volver al dashboard')),
                      const SizedBox(width: 12),
                      OutlinedButton(onPressed: () { if (kIsWeb) { html.window.print(); } else { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Imprimir disponible solo en Web'))); } }, child: const Text('Imprimir comprobante')),
                      const SizedBox(width: 12),
                      OutlinedButton(onPressed: () => context.go('/solicitudes'), child: const Text('Nueva solicitud')),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          Center(child: Text('¿Necesitas ayuda? Contacta al soporte técnico\nsoporte@universidad.edu', textAlign: TextAlign.center)),
        ],
      ),
    );
  }
}

class _KV extends StatelessWidget {
  const _KV({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 260,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: Theme.of(context).textTheme.labelLarge),
        const SizedBox(height: 4),
        Text(value, style: Theme.of(context).textTheme.titleMedium),
      ]),
    );
  }
}
