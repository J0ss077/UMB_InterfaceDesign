import 'package:flutter/material.dart';
import '../../data/mock_repo.dart';
import '../../domain/order.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final lowStock = MockRepo.products.where((p) => p.stock < 20).take(5).toList();
    final recentSales = MockRepo.salesOrders.take(5).toList();
    final recentPurchases = MockRepo.purchaseOrders.take(5).toList();

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 16, runSpacing: 16,
            children: [
              _KpiCard(title: 'Productos', value: MockRepo.products.length.toString(), icon: Icons.category),
              _KpiCard(title: 'Ventas (últimas 2 sem.)', value: recentSales.length.toString(), icon: Icons.point_of_sale),
              _KpiCard(title: 'Compras (últimas 2 sem.)', value: recentPurchases.length.toString(), icon: Icons.shopping_cart),
            ],
          ),
          const SizedBox(height: 24),
          Text('Stock bajo', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Card(
            child: DataTable(
              columns: const [
                DataColumn(label: Text('SKU')),
                DataColumn(label: Text('Producto')),
                DataColumn(label: Text('Stock')),
              ],
              rows: [
                for (final p in lowStock)
                  DataRow(cells: [
                    DataCell(Text(p.sku)),
                    DataCell(Text(p.name)),
                    DataCell(Text(p.stock.toString())),
                  ]),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  const _KpiCard({required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 280,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(child: Icon(icon)),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.labelLarge),
                  Text(value, style: Theme.of(context).textTheme.headlineMedium),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
