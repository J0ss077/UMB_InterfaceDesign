import 'package:flutter/material.dart';
import '../../data/mock_repo.dart';

class ProductsScreen extends StatelessWidget {
  const ProductsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final products = MockRepo.products;
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3, childAspectRatio: 3.6, mainAxisSpacing: 12, crossAxisSpacing: 12),
      itemCount: products.length,
      itemBuilder: (context, i) {
        final p = products[i];
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                const CircleAvatar(child: Icon(Icons.inventory_2)),
                const SizedBox(width: 12),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(p.name, style: Theme.of(context).textTheme.titleMedium, overflow: TextOverflow.ellipsis),
                    Text(p.sku, style: Theme.of(context).textTheme.labelSmall),
                  ],
                )),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('\${p.price.toStringAsFixed(2)}'),
                    Text('Stock: \${p.stock}'),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
